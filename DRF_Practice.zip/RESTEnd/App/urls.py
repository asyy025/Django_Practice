from django.conf.urls import url

from App.views import UserAPIView, UsersAPIView, AddressAPIView

urlpatterns = [
    url(r'^users/$',UsersAPIView.as_view()),
    url(r'^users/(?P<pk>\d+)/$',UserAPIView.as_view(),name='usermodel-detail'),
    url(r'^address/$',AddressAPIView.as_view({ 'post':'create','get':'list',})),
    url(r'^address/(?P<pk>\d+)/$',AddressAPIView.as_view({ 'get':'retrieve',}),name='address-detail'),
]
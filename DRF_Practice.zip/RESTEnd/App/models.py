from django.db import models

# Create your models here.
class UserModel(models.Model):
    u_name = models.CharField(max_length=64,unique=True)
    u_password = models.CharField(max_length=256)

class Address(models.Model):  #外键关联  一对多
    a_address = models.CharField(max_length=128)
    a_user = models.ForeignKey(UserModel,on_delete=models.CASCADE,related_name='address_list',null=True,blank=True)
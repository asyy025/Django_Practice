import uuid

from django.core.cache import cache
from django.shortcuts import render
from rest_framework import exceptions, status
from rest_framework.generics import CreateAPIView,RetrieveAPIView
from rest_framework.response import Response

from App.auth import LoginAuthentication
from App.models import UserModel, Address
from App.permissions import RequireLoginPermission
from App.serializers import UserSerializer, AddressSerializer
from rest_framework import viewsets
# Create your views here.
from App.throttles import UserThrottle


class UsersAPIView(CreateAPIView):
    queryset = UserModel.objects.all()   #关键字 默认为None 在GenericAPIView 中定义
    serializer_class = UserSerializer

    def post(self, request, *args, **kwargs):
        action = request.query_params.get('action')  #地址栏输入的参数
        if action == 'login':
            u_name = request.data.get('u_name')  #客户端提交过来的数据
            u_password = request.data.get('u_password')
            try:
                user = UserModel.objects.get(u_name=u_name)
                if user.u_password != u_password:
                    raise exceptions.AuthenticationFailed
                token = uuid.uuid4().hex  #生成一个用户id的唯一标识
                cache.set(token,user.id,timeout=60*60)  #以token为key,user.id为value的缓存

                data={
                    'msg':'login success',
                    'status':200,
                    'token':token,
                }
                return Response(data)
            except UserModel.DoesNotExist:
                raise exceptions.NotFound
        elif action == 'register':
            return self.create(request,*args,**kwargs)  #返回一个Response对象  Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)
        else:                                           #serializer.data 是UserSerializer的fields字段
            raise exceptions.ParseError

class UserAPIView(RetrieveAPIView):
    queryset = UserModel.objects.all()
    serializer_class = UserSerializer

    authentication_classes = (LoginAuthentication,)  #根据token判断user_id,是否是指定用户，验证用户
    permission_classes = (RequireLoginPermission,)
    throttle_classes = (UserThrottle,)
    # 重写mixin的RetrieveModelMixin的retrieve方法 验证用户身份
    def retrieve(self, request, *args, **kwargs):  #检索一个模型实例
        if kwargs.get('pk') != str(request.user.id):  #第二种写法
            raise exceptions.AuthenticationFailed    #源码多出的部分
        instance = self.get_object()
        # if instance.id != request.user.id:
        #     raise exceptions.AuthenticationFailed  #第一种写法  第三种可以写如中间件

        serializer = self.get_serializer(instance)
        return Response(serializer.data)


class AddressAPIView(viewsets.ModelViewSet):
    serializer_class = AddressSerializer
    queryset = Address.objects.all()

    authentication_classes = (LoginAuthentication,)
    permission_classes = (RequireLoginPermission,)

    #把地址和用户绑定
    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
########添加部分
        user = request.user
        a_id = serializer.data.get('id')
        address = Address.objects.get(pk=a_id)
        address.a_user = user
        address.save()
########
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

    # 重写mixin的ListModelMixin的list方法
    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.queryset.filter(a_user=request.user))

        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)

        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)


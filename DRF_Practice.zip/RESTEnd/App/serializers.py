from rest_framework.serializers import HyperlinkedModelSerializer

from App.models import UserModel,Address

class AddressSerializer(HyperlinkedModelSerializer):
    class Meta:
        model = Address
        fields = ('url','id','a_address')

class UserSerializer(HyperlinkedModelSerializer):
    # address_set = AddressSerializer(many=True,read_only=True)  #被外键关联，有一个隐形字段
    address_list = AddressSerializer(many=True, read_only=True)  #模型中设置related_name=address_list, 即可替代默认address_set
    class Meta:
        model = UserModel
        fields = ('url','id','u_name','u_password','address_list')



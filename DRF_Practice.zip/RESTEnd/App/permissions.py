from rest_framework.permissions import BasePermission

from App.models import UserModel


class RequireLoginPermission(BasePermission):

    def has_permission(self,request,view):
        return isinstance(request.user,UserModel)
    #isinstance() 会认为子类是一种父类类型，考虑继承关系。
    #如果要判断两个类型是否相同推荐使用 isinstance()。